# Xiangqi AI Lab V11 Mobile Build Kit

同一份 V11 FREE 统一客户端封装为：

- Android：原生 WebView 壳，HTML 从 `android/app/src/main/assets/index.html` 加载。
- iOS：原生 WKWebView 壳，HTML 从 App Bundle 的 `Resources/index.html` 加载。

## Android
GitHub Actions `Build Android APK` 会产出 `Xiangqi_AI_Lab_V11_Android.apk`。它是可侧载的 Debug 签名 APK，适合当前校园内测。正式商店发布时应改为稳定 Release Keystore，并永久保存该 Keystore，否则无法平滑更新同一应用。

## iOS
GitHub Actions `Build iOS IPA (unsigned)` 会产出 `Xiangqi_AI_Lab_V11_iOS_unsigned.ipa`。这是未签名 IPA，必须使用有效的 Apple 开发者证书/描述文件或合法的本机签名方式重新签名后才能安装到真机。普通未越狱 iPhone/iPad 不能直接安装未签名 IPA。

## 授权系统
V11 的 Install ID 与 RSA License 逻辑仍由统一 HTML 负责。Android WebView 与 iOS WKWebView 都使用持久化 Web 数据存储，因此正常更新 App 时授权状态可以继续保留；卸载 App / 清除 App 数据可能使 Install ID 重置，需要重新签发许可证。

## GitHub Actions
把整个目录上传到一个仓库的 `main` 分支，Actions 会按路径变化自动构建，也可以在 GitHub Actions 页面手动 `Run workflow`。
